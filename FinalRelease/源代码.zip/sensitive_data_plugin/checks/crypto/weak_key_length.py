"""
SC203: 弱密钥长度检测

此插件检测非对称加密算法中使用不足密钥长度的情况。根据 NIST SP 800-57：

    - RSA 密钥长度 < 2048 位
    - DSA 密钥长度 < 2048 位
    - EC 密钥长度 < 224 位（使用 secp192r1 等弱曲线）

:示例:

.. code-block:: none

    >> Issue: [SC203:weak_key_length] RSA密钥长度1024位不足
       Severity: Medium   Confidence: High
       CWE: CWE-326 (https://cwe.mitre.org/data/definitions/326.html)
       Location: ./examples/crypto.py:5
    5       private_key = rsa.generate_private_key(key_size=1024)

.. seealso::

    - https://cwe.mitre.org/data/definitions/326.html
    - https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-57pt1r5.pdf

.. versionadded:: 1.0.0
"""

import ast

import bandit
from bandit.core import issue
from bandit.core import test_properties as test

from sensitive_data_plugin.checks.base import BaseDetector
from sensitive_data_plugin.utils.constants import WEAK_KEY_SIZES_RSA_DSA, WEAK_EC_CURVES


def _extract_key_size_from_args(args, keywords):
    """从函数参数和关键字参数中提取密钥长度数值。

    Args:
        args: 位置参数列表
        keywords: 关键字参数字典或列表

    Returns:
        int or None: 提取到的密钥长度值
    """
    # 检查位置参数中的整数
    for arg in args:
        if isinstance(arg, ast.Constant) and isinstance(arg.value, int):
            return arg.value
        if isinstance(arg, int):
            return arg

    # 检查关键字参数中的 key_size / keysize
    if isinstance(keywords, dict):
        # 如果是字典格式
        for key in ('key_size', 'keysize'):
            if key in keywords:
                val = keywords[key]
                if isinstance(val, ast.Constant) and isinstance(val.value, int):
                    return val.value
                if isinstance(val, int):
                    return val
    else:
        # 如果是列表格式
        for keyword in keywords:
            if hasattr(keyword, 'arg') and keyword.arg in ('key_size', 'keysize'):
                if hasattr(keyword, 'value'):
                    if isinstance(keyword.value, ast.Constant) and isinstance(keyword.value.value, int):
                        return keyword.value.value
                    if isinstance(keyword.value, int):
                        return keyword.value

    return None


@test.checks("Call")
@test.test_id("SC203")
def weak_key_length(context):
    """SC203: 检测非对称加密中使用弱密钥长度的情况。

    检测生成 RSA、DSA 或 EC 密钥时使用不足的密钥长度。
    标记 RSA/DSA 密钥 < 2048 位和安全强度 < 224 位的 EC 曲线。

    :示例:

    .. code-block:: none

        >> Issue: [SC203:weak_key_length] RSA密钥长度1024位不足
           Severity: Medium   Confidence: High
           CWE: CWE-326 (https://cwe.mitre.org/data/definitions/326.html)
           Location: ./examples/crypto.py:5
        5       private_key = rsa.generate_private_key(key_size=1024)

    .. seealso::

        - https://cwe.mitre.org/data/definitions/326.html
        - https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-57pt1r5.pdf

    .. versionadded:: 1.0.0
    """
    detector = BaseDetector()

    # 检查是否被 # nosec 注释忽略
    if detector.is_ignored(context, None, None):
        return None

    # 获取函数调用信息
    if hasattr(context, 'call_function_name'):
        func_name = context.call_function_name
    elif hasattr(context, 'node') and hasattr(context.node, 'func'):
        func = context.node.func
        if hasattr(func, 'id'):
            func_name = func.id
        elif hasattr(func, 'attr'):
            func_name = func.attr
        else:
            func_name = None
    else:
        func_name = None

    if func_name is None:
        return None

    # 检查 RSA/DSA 密钥生成调用
    rsa_dsa_functions = {'generate_private_key', 'generate_key', 'generate'}
    if func_name in rsa_dsa_functions:
        # 获取模块/类名（例如 rsa.generate_private_key -> rsa）
        module_name = None
        if hasattr(context.node.func, 'value') and hasattr(context.node.func.value, 'id'):
            module_name = context.node.func.value.id

        if module_name in ('rsa', 'RSA', 'dsa', 'DSA'):
            args = getattr(context, 'call_args', [])
            keywords = getattr(context, 'call_keywords', {})

            key_size = _extract_key_size_from_args(args, keywords)

            if key_size is not None and key_size in WEAK_KEY_SIZES_RSA_DSA:
                return detector.create_issue(
                    rule_id='SC203',
                    severity=bandit.MEDIUM,
                    confidence=bandit.HIGH,
                    text=(
                        f"{module_name.upper()}密钥长度{key_size}位不足。"
                        f"请使用2048位或更大的密钥。"
                    ),
                    lineno=context.node.lineno,
                )

            if key_size is not None and key_size < 2048:
                return detector.create_issue(
                    rule_id='SC203',
                    severity=bandit.MEDIUM,
                    confidence=bandit.MEDIUM,
                    text=(
                        f"{module_name.upper()}密钥长度{key_size}位 < 2048位不足。"
                        f"请使用2048位或更大的密钥。"
                    ),
                    lineno=context.node.lineno,
                )

    # 检查 EC 弱曲线使用
    if func_name == 'generate_private_key':
        module_name = None
        if hasattr(context.node.func, 'value') and hasattr(context.node.func.value, 'id'):
            module_name = context.node.func.value.id

        if module_name in ('ec', 'EC'):
            args = getattr(context, 'call_args', [])
            for arg in args:
                # 检查弱 EC 曲线实例化
                if isinstance(arg, ast.Call) and hasattr(arg.func, 'attr'):
                    curve_name = arg.func.attr
                    curve_name_upper = curve_name.upper()
                    for weak_curve in WEAK_EC_CURVES:
                        if weak_curve.upper() in curve_name_upper:
                            return detector.create_issue(
                                rule_id='SC203',
                                severity=bandit.MEDIUM,
                                confidence=bandit.HIGH,
                                text=(
                                    f"检测到弱EC曲线: {curve_name}。"
                                    f"请使用SECP256R1或更强的曲线（>= 224位）。"
                                ),
                                lineno=context.node.lineno,
                            )

    return None