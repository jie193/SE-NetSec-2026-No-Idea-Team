# SC200: 弱哈希算法检测
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from sensitive_data_plugin.utils.constants import WEAK_HASHES

@test.checks("Call")
@test.test_id("SC200")
def weak_hash_algorithm(context):
    """SC200: 检测弱哈希算法的使用

    MD4、MD5和SHA-1哈希函数已被发现存在严重的安全漏洞。强烈建议避免使用这些已被破解的哈希函数。

    此插件检测在 hashlib 和 crypt 模块中使用不安全的 MD4、MD5、SHA-0 或 SHA-1 哈希函数的情况。
    hashlib.new 函数允许通过指定算法名称来构造新的哈希对象。如果将 MD5 和 SHA-1 等不安全算法
    作为参数传入，就会创建不安全的哈希函数。

    此检查还对所有 hashlib 函数变体的 'usedforsecurity' 关键字参数进行额外检查。

    与 hashlib 类似，此插件还检测 crypt 模块中使用弱哈希的情况。crypt 模块也允许使用 MD5 等弱哈希变体。

    :示例:

    .. code-block:: none

        >> Issue: [SC200:weak_hash_algorithm] 使用弱MD5哈希进行安全操作。考虑使用 usedforsecurity=False
           Severity: High   Confidence: High
           CWE: CWE-327 (https://cwe.mitre.org/data/definitions/327.html)
           Location: ./examples/hashlib_md5.py:3
        3       hashlib.md5(b"password")

    .. seealso::

        - https://cwe.mitre.org/data/definitions/327.html
        - https://www.nist.gov/publications/specifications-random-number-generation

    .. versionadded:: 1.0.0

    """
    # 获取函数调用信息
    if hasattr(context, 'call_function_name'):
        func_name = context.call_function_name
    elif hasattr(context, 'node') and hasattr(context.node, 'func'):
        func_name = getattr(context.node.func, 'id', None)
    else:
        func_name = None

    # 检查是否是 hashlib 函数
    if func_name in WEAK_HASHES:
        # 检查 usedforsecurity 参数
        keywords = getattr(context, 'call_keywords', {})
        used_for_security = keywords.get('usedforsecurity', 'True')
        if used_for_security == 'True':
            return bandit.Issue(
                severity=bandit.HIGH,
                confidence=bandit.HIGH,
                cwe=issue.Cwe.BROKEN_CRYPTO,
                text=f"使用弱{WEAK_HASHES[func_name]}哈希进行安全操作。考虑使用 usedforsecurity=False",
                lineno=context.node.lineno,
            )

    # 检查 hashlib.new(name) 模式
    if func_name == 'new':
        args = getattr(context, 'call_args', [])
        keywords = getattr(context, 'call_keywords', {})
        
        # 从参数或关键字参数中获取算法名称
        name = args[0] if args else keywords.get('name', None)
        
        if isinstance(name, str) and name.lower() in WEAK_HASHES:
            used_for_security = keywords.get('usedforsecurity', 'True')
            if used_for_security == 'True':
                return bandit.Issue(
                    severity=bandit.HIGH,
                    confidence=bandit.HIGH,
                    cwe=issue.Cwe.BROKEN_CRYPTO,
                    text=f"使用弱{WEAK_HASHES[name.lower()]}哈希进行安全操作。考虑使用 usedforsecurity=False",
                    lineno=context.node.lineno,
                )

    # 检查 crypt 模块的弱哈希
    if func_name in ('crypt', 'mksalt'):
        args = getattr(context, 'call_args', [])
        keywords = getattr(context, 'call_keywords', {})
        
        if func_name == 'crypt':
            salt = args[1] if len(args) > 1 else keywords.get('salt', None)
            if isinstance(salt, str) and salt in ('METHOD_CRYPT', 'METHOD_MD5', 'METHOD_BLOWFISH'):
                return bandit.Issue(
                    severity=bandit.MEDIUM,
                    confidence=bandit.HIGH,
                    cwe=issue.Cwe.BROKEN_CRYPTO,
                    text=f"使用不安全的 crypt.{salt.replace('METHOD_', '')} 哈希函数",
                    lineno=context.node.lineno,
                )
        elif func_name == 'mksalt':
            method = args[0] if args else keywords.get('method', None)
            if isinstance(method, str) and method in ('METHOD_CRYPT', 'METHOD_MD5', 'METHOD_BLOWFISH'):
                return bandit.Issue(
                    severity=bandit.MEDIUM,
                    confidence=bandit.HIGH,
                    cwe=issue.Cwe.BROKEN_CRYPTO,
                    text=f"在 mksalt 中使用不安全的 crypt.{method.replace('METHOD_', '')} 哈希函数",
                    lineno=context.node.lineno,
                )

    return None