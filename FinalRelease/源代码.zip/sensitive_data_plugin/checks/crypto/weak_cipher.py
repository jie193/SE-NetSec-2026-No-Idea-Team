# SC201: 弱加密算法检测
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from sensitive_data_plugin.checks.base import BaseDetector
from sensitive_data_plugin.utils.constants import WEAK_CIPHERS

@test.checks("Call")
@test.test_id("SC201")
def weak_cipher_algorithm(context):
    """SC201: 检测弱加密算法的使用

    此插件检测使用弱加密算法的情况，如 DES、3DES、RC4、ARCFOUR 和 Blowfish。
    这些算法由于密钥长度过小或存在已知漏洞而被认为是不安全的。

    此插件可以检测多种加密库中的使用情况，包括 PyCrypto、pycryptodome 和其他类似库。

    :示例:

    .. code-block:: none

        >> Issue: [SC201:weak_cipher_algorithm] 使用弱DES加密算法
           Severity: High   Confidence: High
           CWE: CWE-327 (https://cwe.mitre.org/data/definitions/327.html)
           Location: ./examples/cipher.py:5
        5       cipher = DES.new(key, DES.MODE_ECB)

    .. seealso::

        - https://cwe.mitre.org/data/definitions/327.html
        - https://security.openstack.org/guidelines/dg_strong-crypto.html

    .. versionadded:: 1.0.0

    """
    detector = BaseDetector()

    # 检查是否被 # nosec 注释忽略
    if detector.is_ignored(context, None, None):
        return None

    # 获取函数调用信息
    if hasattr(context, 'call_function_name'):
        func_name = context.call_function_name
    elif hasattr(context, 'node') and hasattr(context.node, 'func'):
        func = context.node.func
        if hasattr(func, 'id'):
            func_name = func.id
        elif hasattr(func, 'attr'):
            func_name = func.attr
        else:
            func_name = None
    else:
        func_name = None

    # 检查弱加密算法
    func_name_lower = func_name.lower() if func_name else ''

    for weak_name, display_name in WEAK_CIPHERS.items():
        if weak_name in func_name_lower:
            return detector.create_issue(
                rule_id='SC201',
                severity=bandit.HIGH,
                confidence=bandit.HIGH,
                text=f"使用弱{display_name}加密算法",
                lineno=context.node.lineno,
            )

    # 检查 Crypto.Cipher 模块模式中的弱加密算法
    if func_name:
        if any(weak.upper() in func_name.upper() for weak in WEAK_CIPHERS.keys()):
            return detector.create_issue(
                rule_id='SC201',
                severity=bandit.HIGH,
                confidence=bandit.HIGH,
                text=f"使用弱加密算法",
                lineno=context.node.lineno,
            )

    # 检查调用参数中的弱加密算法名称
    args = getattr(context, 'call_args', [])
    keywords = getattr(context, 'call_keywords', {})

    for weak_name, display_name in WEAK_CIPHERS.items():
        # 检查参数中是否包含弱加密算法名称
        for arg in args:
            if isinstance(arg, str) and weak_name in arg.lower():
                return detector.create_issue(
                    rule_id='SC201',
                    severity=bandit.HIGH,
                    confidence=bandit.HIGH,
                    text=f"使用弱{display_name}加密算法",
                    lineno=context.node.lineno,
                )

        # 检查关键字参数
        for key, value in keywords.items():
            if isinstance(value, str) and weak_name in value.lower():
                return detector.create_issue(
                    rule_id='SC201',
                    severity=bandit.HIGH,
                    confidence=bandit.HIGH,
                    text=f"使用弱{display_name}加密算法",
                    lineno=context.node.lineno,
                )

    return None