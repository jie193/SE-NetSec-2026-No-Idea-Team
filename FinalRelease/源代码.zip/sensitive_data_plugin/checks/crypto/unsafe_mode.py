# SC202: 不安全加密模式检测
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from sensitive_data_plugin.checks.base import BaseDetector
from sensitive_data_plugin.utils.constants import WEAK_MODES

@test.checks("Call")
@test.test_id("SC202")
def unsafe_encryption_mode(context):
    """SC202: 检测不安全加密模式的使用

    此插件检测使用不安全加密模式的情况，如 ECB（电子密码本）模式。
    ECB 模式被认为是不安全的，因为它会将相同的明文块加密成相同的密文块，
    从而泄露数据中的模式信息。

    此插件检测 Crypto.Cipher 模块和类似加密库中的 ECB 模式使用情况。

    :示例:

    .. code-block:: none

        >> Issue: [SC202:unsafe_encryption_mode] 使用不安全的ECB加密模式
           Severity: High   Confidence: High
           CWE: CWE-327 (https://cwe.mitre.org/data/definitions/327.html)
           Location: ./examples/cipher.py:5
        5       cipher = AES.new(key, AES.MODE_ECB)

    .. seealso::

        - https://cwe.mitre.org/data/definitions/327.html
        - https://security.openstack.org/guidelines/dg_strong-crypto.html

    .. versionadded:: 1.0.0

    """
    detector = BaseDetector()

    # 检查是否被 # nosec 注释忽略
    if detector.is_ignored(context, None, None):
        return None

    # 获取函数调用信息
    if hasattr(context, 'call_function_name'):
        func_name = context.call_function_name
    elif hasattr(context, 'node') and hasattr(context.node, 'func'):
        func = context.node.func
        if hasattr(func, 'id'):
            func_name = func.id
        elif hasattr(func, 'attr'):
            func_name = func.attr
        else:
            func_name = None
    else:
        func_name = None

    # 检查函数名中是否包含 ECB 模式或 MODE_ECB
    func_name_upper = func_name.upper() if func_name else ''
    if 'ECB' in func_name_upper or 'MODE_ECB' in func_name_upper:
        return detector.create_issue(
            rule_id='SC202',
            severity=bandit.HIGH,
            confidence=bandit.HIGH,
            text=f"使用不安全的ECB加密模式",
            lineno=context.node.lineno,
        )

    # 检查调用参数中的 ECB 模式
    args = getattr(context, 'call_args', [])
    keywords = getattr(context, 'call_keywords', {})

    for arg in args:
        if isinstance(arg, str) and 'ecb' in arg.lower():
            return detector.create_issue(
                rule_id='SC202',
                severity=bandit.HIGH,
                confidence=bandit.HIGH,
                text=f"使用不安全的ECB加密模式",
                lineno=context.node.lineno,
            )
        # 检查模块属性，如 AES.MODE_ECB
        if hasattr(arg, 'attr') and 'ECB' in arg.attr.upper():
            return detector.create_issue(
                rule_id='SC202',
                severity=bandit.HIGH,
                confidence=bandit.HIGH,
                text=f"使用不安全的ECB加密模式",
                lineno=context.node.lineno,
            )

    # 检查关键字参数
    for key, value in keywords.items():
        if isinstance(value, str) and 'ecb' in value.lower():
            return detector.create_issue(
                rule_id='SC202',
                severity=bandit.HIGH,
                confidence=bandit.HIGH,
                text=f"使用不安全的ECB加密模式",
                lineno=context.node.lineno,
            )
        # 检查模块属性
        if hasattr(value, 'attr') and 'ECB' in str(value.attr).upper():
            return detector.create_issue(
                rule_id='SC202',
                severity=bandit.HIGH,
                confidence=bandit.HIGH,
                text=f"使用不安全的ECB加密模式",
                lineno=context.node.lineno,
            )

    return None