# SC101: 字典键值对中的敏感信息检测
import ast
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from sensitive_data_plugin.utils.constants import SENSITIVE_KEYWORD_REGEX
from sensitive_data_plugin.utils.filters import should_ignore

@test.checks("Str")
@test.test_id("SC101")
def dict_sensitive_info(context):
    """SC101: 检测字典键值对中的敏感信息

    此插件检测用作字典键的字符串字面量，并检查相应的值是否看起来像敏感信息。

    键名被认为像敏感信息的情况包括：
    - "password", "pass", "passwd", "pwd"
    - "secret", "secrete"
    - "token", "auth_token", "access_token"
    - "api_key", "api_secret", "access_key"
    - "credential", "credentials"

    :示例:

    .. code-block:: none

        >> Issue: [SC101:dict_sensitive_info] 字典中可能存在硬编码敏感信息: 'sk-1234567890abcdef'
           Severity: High   Confidence: Medium
           CWE: CWE-259 (https://cwe.mitre.org/data/definitions/259.html)
           Location: ./examples/config.py:5
        5     config = {"api_key": "sk-1234567890abcdef"}

    .. seealso::

        - https://www.owasp.org/index.php/Use_of_hard-coded_password
        - https://cwe.mitre.org/data/definitions/259.html

    .. versionadded:: 1.0.0

    """
    node = context.node

    # 检查节点是否是字典的键
    if isinstance(node._bandit_parent, ast.Dict):
        dict_node = node._bandit_parent
        if node in dict_node.keys:
            # 获取键名
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                key_name = node.value
            elif isinstance(node, ast.Str):  # Python < 3.8 兼容性
                key_name = node.s
            else:
                return None

            # 检查键名是否看起来像敏感关键字
            if SENSITIVE_KEYWORD_REGEX.search(key_name):
                # 获取对应的值
                pos = dict_node.keys.index(node)
                value_node = dict_node.values[pos]

                # 获取值
                if isinstance(value_node, ast.Constant):
                    value = value_node.value
                elif isinstance(value_node, ast.Str):  # Python < 3.8 兼容性
                    value = value_node.s
                else:
                    return None

                # 检查值是否是潜在的敏感值
                if isinstance(value, str) and len(value) >= 6:
                    if should_ignore(context, value, key_name):
                        return None
                    return bandit.Issue(
                        severity=bandit.HIGH,
                        confidence=bandit.MEDIUM,
                        cwe=issue.Cwe.HARD_CODED_PASSWORD,
                        text=f"字典中可能存在硬编码敏感信息: '{value}'",
                        lineno=node.lineno,
                    )

    # 检查下标赋值: dict["key"] = "value"
    elif isinstance(node._bandit_parent, ast.Subscript):
        subscript_node = node._bandit_parent
        # 下标是键，检查其父节点是否是赋值语句
        if hasattr(subscript_node, '_bandit_parent') and isinstance(subscript_node._bandit_parent, ast.Assign):
            assign_node = subscript_node._bandit_parent
            # 从下标中获取键
            if isinstance(subscript_node.slice, ast.Index):
                index_node = subscript_node.slice
                if hasattr(index_node, '_bandit_parent'):
                    key_node = index_node._bandit_parent
                    if isinstance(key_node, ast.Constant):
                        key_name = key_node.value
                    elif isinstance(key_node, ast.Str):
                        key_name = key_node.s
                    else:
                        return None

                    if SENSITIVE_KEYWORD_REGEX.search(str(key_name)):
                        # 获取赋值的值
                        if isinstance(assign_node.value, ast.Constant):
                            value = assign_node.value.value
                        elif isinstance(assign_node.value, ast.Str):
                            value = assign_node.value.s
                        else:
                            return None

                        if isinstance(value, str) and len(value) >= 6:
                            if should_ignore(context, value, key_name):
                                return None
                            return bandit.Issue(
                                severity=bandit.HIGH,
                                confidence=bandit.MEDIUM,
                                cwe=issue.Cwe.HARD_CODED_PASSWORD,
                                text=f"字典中可能存在硬编码敏感信息: '{value}'",
                                lineno=node.lineno,
                            )

    return None