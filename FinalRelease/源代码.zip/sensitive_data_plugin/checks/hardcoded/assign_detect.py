# SC100: 变量赋值中的硬编码密码检测
import ast
import bandit
from bandit.core import issue
from bandit.core import test_properties as test
from sensitive_data_plugin.utils.constants import (
    SENSITIVE_KEYWORD_REGEX,
    API_KEY_REGEXES
)
from sensitive_data_plugin.utils.filters import should_ignore

@test.checks("Str")
@test.test_id("SC100")
def hardcoded_password_assign(context):
    """SC100: 检测变量赋值中的硬编码密码

    使用硬编码密码会极大增加密码被猜测的可能性。此插件检测所有字符串字面量，
    并检查它们是否被赋值给看起来像密码的变量。

    变量名被认为像密码的情况包括：
    - "password", "pass", "passwd", "pwd"
    - "secret", "secrete"
    - "token"
    - "api_key", "api_secret", "access_key"
    - "credential", "credentials"

    :示例:

    .. code-block:: none

        >> Issue: [SC100:hardcoded_password_assign] 可能存在硬编码密码: 'secret123'
           Severity: High   Confidence: Medium
           CWE: CWE-259 (https://cwe.mitre.org/data/definitions/259.html)
           Location: ./examples/hardcoded_passwords.py:5
        5     password = "secret123"

    .. seealso::

        - https://www.owasp.org/index.php/Use_of_hard-coded_password
        - https://cwe.mitre.org/data/definitions/259.html

    .. versionadded:: 1.0.0

    """
    node = context.node

    # 检查节点是否是赋值语句的一部分
    if isinstance(node._bandit_parent, ast.Assign):
        # 检查是否有目标变量看起来像密码
        for targ in node._bandit_parent.targets:
            if isinstance(targ, ast.Name):
                if SENSITIVE_KEYWORD_REGEX.search(targ.id):
                    # 检查值是否是潜在的敏感值
                    value = node.value
                    if isinstance(value, str) and len(value) >= 6:
                        # 检查是否应该忽略此检测
                        if should_ignore(context, value, targ.id):
                            return None
                        return bandit.Issue(
                            severity=bandit.HIGH,
                            confidence=bandit.MEDIUM,
                            cwe=issue.Cwe.HARD_CODED_PASSWORD,
                            text=f"可能存在硬编码密码: '{value}'",
                            lineno=node.lineno,
                        )
            elif isinstance(targ, ast.Attribute):
                if SENSITIVE_KEYWORD_REGEX.search(targ.attr):
                    value = node.value
                    if isinstance(value, str) and len(value) >= 6:
                        if should_ignore(context, value, targ.attr):
                            return None
                        return bandit.Issue(
                            severity=bandit.HIGH,
                            confidence=bandit.MEDIUM,
                            cwe=issue.Cwe.HARD_CODED_PASSWORD,
                            text=f"可能存在硬编码密码: '{value}'",
                            lineno=node.lineno,
                        )

    return None