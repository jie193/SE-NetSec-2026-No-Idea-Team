# 所有敏感数据检测的基础检测器类
import bandit
from bandit.core import issue
from sensitive_data_plugin.utils.filters import should_ignore
from sensitive_data_plugin.utils.constants import RULES

class BaseDetector:
    """所有敏感数据检测器的基类
    
    此类为所有检测器提供通用功能，包括：
    - Issue 创建
    - 误报过滤
    - 规则信息访问
    """
    
    def __init__(self):
        pass
    
    def create_issue(self, rule_id, severity, confidence, text, lineno=None):
        """创建标准化的 Issue 对象
        
        Args:
            rule_id: 规则ID（如 'SC100'）
            severity: 严重级别（bandit.LOW, bandit.MEDIUM, bandit.HIGH）
            confidence: 置信度级别（bandit.LOW, bandit.MEDIUM, bandit.HIGH）
            text: 问题描述文本
            lineno: 问题所在行号（可选）
            
        Returns:
            bandit.Issue: 创建的 Issue 对象
        """
        cwe_mapping = {
            'SC100': issue.Cwe.HARD_CODED_PASSWORD,
            'SC101': issue.Cwe.HARD_CODED_PASSWORD,
            'SC102': issue.Cwe.HARD_CODED_PASSWORD,
            'SC200': issue.Cwe.BROKEN_CRYPTO,
            'SC201': issue.Cwe.BROKEN_CRYPTO,
            'SC202': issue.Cwe.BROKEN_CRYPTO,
            'SC203': issue.Cwe.INADEQUATE_ENCRYPTION_STRENGTH,
        }
        
        cwe = cwe_mapping.get(rule_id, issue.Cwe.HARD_CODED_PASSWORD)
        
        return bandit.Issue(
            severity=severity,
            confidence=confidence,
            cwe=cwe,
            text=text,
            lineno=lineno
        )
    
    def get_rule_info(self, rule_id):
        """获取特定规则的信息
        
        Args:
            rule_id: 规则ID（如 'SC100'）
            
        Returns:
            dict: 规则信息，包括名称、描述、严重级别和置信度
        """
        return RULES.get(rule_id, {})
    
    def get_severity(self, rule_id):
        """获取规则的严重级别
        
        Args:
            rule_id: 规则ID
            
        Returns:
            int: 严重级别（bandit.LOW, bandit.MEDIUM, bandit.HIGH）
        """
        severity_map = {
            'LOW': bandit.LOW,
            'MEDIUM': bandit.MEDIUM,
            'HIGH': bandit.HIGH,
        }
        rule_info = self.get_rule_info(rule_id)
        return severity_map.get(rule_info.get('severity', 'MEDIUM'), bandit.MEDIUM)
    
    def get_confidence(self, rule_id):
        """获取规则的置信度级别
        
        Args:
            rule_id: 规则ID
            
        Returns:
            int: 置信度级别（bandit.LOW, bandit.MEDIUM, bandit.HIGH）
        """
        confidence_map = {
            'LOW': bandit.LOW,
            'MEDIUM': bandit.MEDIUM,
            'HIGH': bandit.HIGH,
        }
        rule_info = self.get_rule_info(rule_id)
        return confidence_map.get(rule_info.get('confidence', 'MEDIUM'), bandit.MEDIUM)
    
    def is_ignored(self, context, value, name=None):
        """检查检测结果是否应该被忽略
        
        Args:
            context: Bandit 上下文对象
            value: 要检查的值
            name: 变量/参数名称（可选）
            
        Returns:
            bool: 如果应该忽略则返回 True
        """
        return should_ignore(context, value, name)
    
    def detect(self, context):
        """子类必须实现的主要检测方法
        
        Args:
            context: Bandit 上下文对象
            
        Returns:
            bandit.Issue 或 None: 检测到的问题，如果没有问题则返回 None
        """
        raise NotImplementedError("子类必须实现 detect 方法")