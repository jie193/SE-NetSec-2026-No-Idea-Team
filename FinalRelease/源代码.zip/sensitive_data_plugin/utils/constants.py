# 敏感数据检测常量
import re

# 敏感关键词模式
SENSITIVE_KEYWORDS = (
    r'(api[_-]?key|secret|token|password|pwd|'
    r'access[_-]?key|private[_-]?key|public[_-]?key|'
    r'auth[_-]?token|secret[_-]?key|api[_-]?secret|'
    r'credential|credentials|pass|passwd|secret_key|'
    r'access_token|refresh_token|api_secret|auth_key)'
)

# 编译后的敏感关键词正则表达式
SENSITIVE_KEYWORD_REGEX = re.compile(SENSITIVE_KEYWORDS, re.IGNORECASE)

# API 密钥格式模式
API_KEY_PATTERNS = [
    r'^AKIA[0-9A-Z]{16}$',              # AWS access key
    r'^sk-[a-zA-Z0-9]{20,}$',           # OpenAI secret key
    r'^pk-[a-zA-Z0-9]{20,}$',           # Stripe publishable key
    r'^[a-zA-Z0-9+/=]{40,}$',            # Base64 encoded key
    r'^[a-f0-9]{32,}$',                  # Hex encoded key
    r'^[a-zA-Z0-9]{32,}$',               # Generic API key
]

# 编译后的 API 密钥正则表达式模式
API_KEY_REGEXES = [re.compile(pattern) for pattern in API_KEY_PATTERNS]

# 弱哈希算法
WEAK_HASHES = {
    'md4': 'MD4',
    'md5': 'MD5',
    'sha': 'SHA-0',
    'sha1': 'SHA-1',
}

# 弱加密算法
WEAK_CIPHERS = {
    'des': 'DES',
    '3des': '3DES',
    'rc4': 'RC4',
    'arcfour': 'ARCFOUR',
    'blowfish': 'Blowfish',
}

# 弱加密模式
WEAK_MODES = {
    'ecb': 'ECB',
}

# RSA/DSA 的弱密钥长度（位）
WEAK_KEY_SIZES_RSA_DSA = {
    512,
    768,
    1024,
}

# 弱 EC 曲线
WEAK_EC_CURVES = {
    'secp192r1',
    'prime192v1',
    'secp112r1',
    'secp112r2',
    'secp128r1',
    'secp128r2',
    'secp160k1',
    'secp160r1',
    'secp160r2',
}

# 最小密钥长度（位）
MIN_KEY_LENGTHS = {
    'RSA': 2048,
    'DSA': 2048,
    'EC': 224,
}

# 常见无风险常量
COMMON_CONSTANTS = [
    'localhost',
    '127.0.0.1',
    '0.0.0.0',
    'default',
    'test',
    'example',
    'demo',
    'dev',
    'development',
    'staging',
    'prod',
    'production',
    'local',
    'none',
    'null',
    'true',
    'false',
    'yes',
    'no',
    'on',
    'off',
    'enable',
    'disable',
    'enabled',
    'disabled',
    'active',
    'inactive',
    'success',
    'error',
    'warning',
    'info',
]

# 敏感数据的最小字符串长度
MIN_SENSITIVE_LENGTH = 6

# 规则ID和描述
RULES = {
    'SC100': {
        'name': 'hardcoded_password_assign',
        'description': '变量赋值中的硬编码密码',
        'severity': 'HIGH',
        'confidence': 'MEDIUM',
        'owasp_top_10': 'A02:2021 - 加密失败',
        'gb_t_22239': 'GB/T 22239-2019 第5.2.2.2条',
        'fix_recommendation': '从源代码中移除硬编码密码。使用环境变量或安全的密钥管理服务存储敏感凭证。',
    },
    'SC101': {
        'name': 'dict_sensitive_info',
        'description': '字典键值对中的敏感信息',
        'severity': 'HIGH',
        'confidence': 'MEDIUM',
        'owasp_top_10': 'A02:2021 - 加密失败',
        'gb_t_22239': 'GB/T 22239-2019 第5.2.2.2条',
        'fix_recommendation': '从字典中移除敏感数据。将敏感信息存储在安全的存储机制中。',
    },
    'SC102': {
        'name': 'funcarg_sensitive_info',
        'description': '函数调用参数中的敏感信息',
        'severity': 'HIGH',
        'confidence': 'MEDIUM',
        'owasp_top_10': 'A02:2021 - 加密失败',
        'gb_t_22239': 'GB/T 22239-2019 第5.2.2.2条',
        'fix_recommendation': '避免将敏感数据作为明文函数参数传递。使用安全的参数传递机制。',
    },
    'SC200': {
        'name': 'weak_hash_algorithm',
        'description': '弱哈希算法使用',
        'severity': 'HIGH',
        'confidence': 'HIGH',
        'owasp_top_10': 'A02:2021 - 加密失败',
        'gb_t_22239': 'GB/T 22239-2019 第5.2.2.3条',
        'fix_recommendation': '将弱哈希算法（MD5、SHA-1）替换为强算法，如 SHA-256 或 SHA-3。',
    },
    'SC201': {
        'name': 'weak_cipher_algorithm',
        'description': '弱加密算法使用',
        'severity': 'HIGH',
        'confidence': 'HIGH',
        'owasp_top_10': 'A02:2021 - 加密失败',
        'gb_t_22239': 'GB/T 22239-2019 第5.2.2.3条',
        'fix_recommendation': '将弱加密算法（DES、3DES、RC4）替换为强算法，如 AES-256-GCM。',
    },
    'SC202': {
        'name': 'unsafe_encryption_mode',
        'description': '不安全的加密模式',
        'severity': 'HIGH',
        'confidence': 'HIGH',
        'owasp_top_10': 'A02:2021 - 加密失败',
        'gb_t_22239': 'GB/T 22239-2019 第5.2.2.3条',
        'fix_recommendation': '将 ECB 模式替换为安全模式，如 CBC、GCM 或 CTR。始终使用认证加密模式。',
    },
    'SC203': {
        'name': 'weak_cryptographic_key',
        'description': '弱加密密钥长度',
        'severity': 'HIGH',
        'confidence': 'HIGH',
        'owasp_top_10': 'A02:2021 - 加密失败',
        'gb_t_22239': 'GB/T 22239-2019 第5.2.2.3条',
        'fix_recommendation': '使用足够长度的加密密钥：RSA/DSA 密钥至少 2048 位，EC 密钥至少 224 位。',
    },
}