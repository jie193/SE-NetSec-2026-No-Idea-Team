# 误报过滤工具函数
import re
from sensitive_data_plugin.utils.constants import (
    COMMON_CONSTANTS, 
    MIN_SENSITIVE_LENGTH,
    SENSITIVE_KEYWORD_REGEX
)

def is_nosec_line(context):
    """检查行是否被 # nosec 注释忽略
    
    Args:
        context: Bandit 上下文对象
        
    Returns:
        bool: 如果行被 # nosec 忽略则返回 True
    """
    if hasattr(context, 'nosec_lines'):
        return context.node.lineno in context.nosec_lines
    return False

def is_common_constant(value):
    """检查值是否是常见的无风险常量
    
    Args:
        value: 要检查的字符串值
        
    Returns:
        bool: 如果值是常见的无风险常量则返回 True
    """
    if not isinstance(value, str):
        return False
    return value.lower() in COMMON_CONSTANTS

def is_short_string(value):
    """检查字符串是否太短而不可能是敏感值
    
    Args:
        value: 要检查的字符串值
        
    Returns:
        bool: 如果字符串太短则返回 True
    """
    if not isinstance(value, str):
        return False
    return len(value) < MIN_SENSITIVE_LENGTH

def contains_sensitive_keyword(name):
    """检查名称是否包含敏感关键字
    
    Args:
        name: 变量/参数名称
        
    Returns:
        bool: 如果名称包含敏感关键字则返回 True
    """
    if not isinstance(name, str):
        return False
    return bool(SENSITIVE_KEYWORD_REGEX.search(name))

def is_false_positive(context, value=None, name=None):
    """检查检测结果是否是误报
    
    Args:
        context: Bandit 上下文对象
        value: 要检查的值（可选）
        name: 变量/参数名称（可选）
        
    Returns:
        bool: 如果是误报则返回 True
    """
    # 检查行是否被 # nosec 忽略
    if is_nosec_line(context):
        return True
    
    # 检查值是否是常见常量
    if value is not None and is_common_constant(value):
        return True
    
    # 检查字符串是否太短
    if value is not None and is_short_string(value):
        return True
    
    # 检查名称是否包含敏感关键字（如果提供了名称）
    if name is not None and not contains_sensitive_keyword(name):
        return True
    
    return False

def get_line_content(file_path, line_number):
    """获取文件中特定行的内容
    
    Args:
        file_path: 文件路径
        line_number: 行号
        
    Returns:
        str: 该行的内容，如果未找到则返回空字符串
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            if 0 < line_number <= len(lines):
                return lines[line_number - 1].strip()
    except Exception:
        pass
    return ""

def is_ignored_pattern(value):
    """检查值是否匹配任何忽略模式
    
    Args:
        value: 要检查的字符串值
        
    Returns:
        bool: 如果值匹配忽略模式则返回 True
    """
    if not isinstance(value, str):
        return False
    
    # 可能不敏感的模式
    ignored_patterns = [
        r'^\d+$',  # 纯数字
        r'^[a-zA-Z0-9]{1,5}$',  # 短字母数字组合
        r'^https?://',  # URL
        r'^\w+@\w+\.\w+$',  # 邮箱地址
    ]
    
    for pattern in ignored_patterns:
        if re.match(pattern, value):
            return True
    
    return False

def should_ignore(context, value, name=None):
    """确定检测结果是否应该被忽略
    
    Args:
        context: Bandit 上下文对象
        value: 要检查的值
        name: 变量/参数名称（可选）
        
    Returns:
        bool: 如果应该忽略则返回 True
    """
    return (
        is_false_positive(context, value, name) or
        is_ignored_pattern(value)
    )