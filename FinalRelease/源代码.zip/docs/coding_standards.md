# Bandit 敏感信息检测插件 - 代码规范

## 1. 项目结构规范

### 1.1 目录结构

```
bandit/
├── sensitive_data_plugin/          # 主插件包
│   ├── checks/                     # 检测规则实现
│   │   ├── __init__.py
│   │   ├── base.py                 # 基础检测类
│   │   ├── crypto/                 # 加密安全检测
│   │   │   ├── __init__.py
│   │   │   ├── weak_hash.py
│   │   │   ├── weak_cipher.py
│   │   │   ├── unsafe_mode.py
│   │   │   └── weak_key_length.py
│   │   └── hardcoded/              # 硬编码检测
│   │       ├── __init__.py
│   │       ├── assign_detect.py
│   │       ├── dict_detect.py
│   │       └── funcarg_detect.py
│   ├── tests/                      # 测试代码
│   │   ├── __init__.py
│   │   ├── samples/                # 测试样本
│   │   ├── test_crypto.py          # 加密检测测试
│   │   ├── test_hardcoded.py       # 硬编码检测测试
│   │   └── test_integration.py     # 集成测试
│   ├── utils/                      # 工具函数
│   │   ├── __init__.py
│   │   ├── constants.py            # 常量定义
│   │   └── filters.py              # 误报过滤
│   └── __init__.py
├── docs/                           # 文档
├── .editorconfig                   # 编辑器配置
├── .gitignore                      # Git 忽略规则
├── setup.cfg                       # 包配置
├── setup.py                        # 安装脚本
└── requirements.txt                # 依赖声明
```

### 1.2 文件命名规则

| 文件类型 | 命名规则 | 示例 |
|----------|----------|------|
| 模块文件 | 全小写 + 下划线 | `weak_cipher.py` |
| 测试文件 | `test_` + 模块名 | `test_crypto.py` |
| 样本文件 | `{功能}_{类型}.py` | `crypto_vuln.py`, `crypto_clean.py` |

---

## 2. Python 编码规范

### 2.1 PEP 8 遵循原则

- **缩进**：4 个空格，禁止使用 Tab
- **行宽**：限制 79 字符（注释/文档字符串 72 字符）
- **空行**：
  - 函数/类之间使用 2 个空行
  - 类内方法之间使用 1 个空行
  - 逻辑段落之间使用 1 个空行

### 2.2 代码格式化工具

**强制使用**：
- **Black**：统一代码格式化
- **isort**：自动排序 import
- **flake8**：代码风格检查

配置示例（`pyproject.toml`）：
```toml
[tool.black]
line-length = 79
target-version = ["py38", "py39", "py310"]

[tool.isort]
profile = "black"
line_length = 79
```

---

## 3. 命名规范

| 类型 | 规则 | 示例 |
|------|------|------|
| 模块 | 全小写 + 下划线 | `weak_cipher.py` |
| 包 | 全小写 + 下划线 | `sensitive_data_plugin` |
| 函数 | 全小写 + 下划线 | `create_issue()` |
| 类 | 大驼峰命名 | `BaseDetector` |
| 变量 | 全小写 + 下划线 | `func_name_lower` |
| 常量 | 全大写 + 下划线 | `WEAK_CIPHERS` |
| 方法 | 全小写 + 下划线 | `is_ignored()` |
| 私有成员 | 前导下划线 | `_cwe_mapping` |
| 规则ID | 大写字母 + 数字 | `SC201` |

---

## 4. Bandit 插件开发规范

### 4.1 装饰器顺序

**必须遵循以下顺序**：

```python
@test.checks("Call")          # 第一：指定检测类型
@test.test_id("SC201")        # 第二：指定规则ID
def weak_cipher_algorithm(context):
    # 检测逻辑
    pass
```

### 4.2 检测类型说明

| 装饰器参数 | 检测对象 | 适用场景 |
|------------|----------|----------|
| `"Str"` | 字符串字面量 | 硬编码检测 |
| `"Call"` | 函数调用 | 加密算法检测 |
| `"Assign"` | 变量赋值 | 敏感赋值检测 |
| `"Dict"` | 字典定义 | 字典敏感信息检测 |

### 4.3 Issue 返回规范

必须返回标准的 `bandit.Issue` 对象：

```python
return bandit.Issue(
    severity=bandit.HIGH,           # 严重级别
    confidence=bandit.HIGH,         # 置信度
    cwe=issue.Cwe.BROKEN_CRYPTO,    # CWE 编号
    text="检测描述文本",              # 问题描述
    lineno=context.node.lineno      # 行号
)
```

### 4.4 CWE 映射表

| 规则类型 | CWE 编号 | 说明 |
|----------|----------|------|
| 硬编码密码 | `Cwe.HARD_CODED_PASSWORD` | CWE-259 |
| 弱加密算法 | `Cwe.BROKEN_CRYPTO` | CWE-327 |
| 密钥长度不足 | `Cwe.INADEQUATE_ENCRYPTION_STRENGTH` | CWE-326 |

---

## 5. 注释和文档规范

### 5.1 文档字符串（Docstring）

**强制要求**：所有模块、类、函数必须包含完整的 docstring，采用 **Google 风格**：

```python
def create_issue(self, rule_id, severity, confidence, text, lineno=None):
    """创建标准化的 Issue 对象

    Args:
        rule_id: 规则ID（如 'SC100'）
        severity: 严重级别（bandit.LOW/MEDIUM/HIGH）
        confidence: 置信度（bandit.LOW/MEDIUM/HIGH）
        text: 问题描述文本
        lineno: 问题所在行号（可选）

    Returns:
        bandit.Issue: 创建的 Issue 对象

    """
```

### 5.2 代码注释

- **单行注释**：使用 `#`，注释内容与 `#` 之间保留一个空格
- **复杂逻辑**：必须附带清晰的注释说明
- **TODO 注释**：使用 `# TODO: 描述待完成事项`

### 5.3 文档示例格式

检测规则文档需包含：
- 规则说明
- 严重级别/置信度
- CWE 链接
- 示例输出
- 修复建议

---

## 6. 测试规范

### 6.1 测试文件结构

```
tests/
├── samples/              # 测试样本代码
│   ├── crypto_vuln.py    # 加密漏洞样本
│   ├── crypto_clean.py   # 加密安全样本
│   ├── hardcoded_vuln.py # 硬编码漏洞样本
│   └── hardcoded_clean.py# 硬编码安全样本
├── test_crypto.py        # 加密检测单元测试
├── test_hardcoded.py     # 硬编码检测单元测试
└── test_integration.py   # 集成测试
```

### 6.2 测试命名规范

| 测试类型 | 命名规则 | 示例 |
|----------|----------|------|
| 单元测试 | `test_` + 规则ID | `test_sc200_weak_hash()` |
| 集成测试 | `test_integration_` + 功能 | `test_integration_plugin_load()` |
| 性能测试 | `test_perf_` + 功能 | `test_perf_large_codebase()` |

### 6.3 pytest Fixture 规范

```python
import pytest
import bandit
from bandit.core import manager, config as bandit_config

@pytest.fixture
def bandit_manager():
    """创建 BanditManager 实例的 fixture"""
    conf = bandit_config.BanditConfig(config_file=None)
    return manager.BanditManager(
        config=conf,
        agg_type='vuln',
        debug=False,
        verbose=True,
        quiet=False,
        profile=None,
        ignore_nosec=False,
    )

@pytest.fixture
def plugin_path():
    """获取插件路径"""
    import os
    return os.path.join(os.path.dirname(__file__), "..")

@pytest.fixture
def sample_path():
    """获取样本文件路径"""
    import os
    return os.path.join(os.path.dirname(__file__), "samples")
```

### 6.4 测试用例结构

每个测试用例必须包含：
- **漏洞样本测试**：验证漏洞被正确检测
- **安全样本测试**：验证无误报
- **边界条件测试**：验证边缘情况处理

---

## 7. Git 工作流规范

### 7.1 分支命名规则

| 分支类型 | 命名规则 | 示例 |
|----------|----------|------|
| 功能开发 | `feature/` + 功能名 | `feature/sc204-weak-key` |
| Bug 修复 | `bugfix/` + 问题描述 | `bugfix/false-positive-filter` |
| 文档更新 | `docs/` + 主题 | `docs/coding-standard` |
| 重构 | `refactor/` + 模块名 | `refactor/base-detector` |

### 7.2 Commit Message 规范

采用 **Conventional Commits** 格式：

```
<type>(<scope>): <description>

[optional body]

[optional footer(s)]
```

**类型说明**：
| 类型 | 说明 |
|------|------|
| `feat` | 新功能 |
| `fix` | Bug 修复 |
| `docs` | 文档更新 |
| `style` | 代码风格调整（不影响功能） |
| `refactor` | 代码重构 |
| `test` | 测试代码更新 |
| `chore` | 构建/工具配置更新 |

**示例**：
```
feat(checks): add SC204 weak key detection rule

- Implement weak_key_length.py
- Add RSA/DSA/EC key size validation
- Update constants.py with minimum key lengths
```

### 7.3 Pull Request 流程

1. **提交 PR**：标题清晰描述变更内容
2. **自动检查**：CI 自动运行测试和代码检查
3. **代码审查**：至少 1 位 reviewer 审核
4. **合并**：通过审核后合并到主分支

---

## 8. 工具配置

### 8.1 EditorConfig

```ini
# .editorconfig
root = true

[*]
indent_style = space
indent_size = 4
end_of_line = lf
charset = utf-8
trim_trailing_whitespace = true
insert_final_newline = true

[*.py]
indent_style = space
indent_size = 4

[*.{yml,yaml}]
indent_style = space
indent_size = 2

[*.md]
indent_style = space
indent_size = 4
trim_trailing_whitespace = false
```

### 8.2 .gitignore

```gitignore
# .gitignore
# Python
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
env/
venv/
.venv/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# Testing
.pytest_cache/
.coverage
htmlcov/

# Build
dist/
build/
*.egg-info/

# OS
.DS_Store
Thumbs.db
```

### 8.3 CI/CD 配置（GitHub Actions）

```yaml
# .github/workflows/ci.yml
name: CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.8", "3.9", "3.10"]
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v5
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install black isort flake8 pytest bandit
    
    - name: Run lint checks
      run: |
        flake8 . --count --select=E,F,W --max-line-length=79
        black --check .
        isort --check .
    
    - name: Run tests
      run: |
        pytest tests/ -v --tb=short
```

---

## 9. 安全注意事项

### 9.1 敏感信息防护

- **禁止**在代码中硬编码密码、密钥、Token 等敏感信息
- 使用环境变量或配置文件管理敏感配置
- 测试样本中的敏感数据必须使用占位符或无效数据

### 9.2 依赖安全

- 定期更新依赖包，修复已知安全漏洞
- 使用 `bandit` 扫描项目本身代码
- 审查第三方库的安全性

---

## 附录：规则 ID 命名规范

| 规则前缀 | 类别 | 示例 |
|----------|------|------|
| `SC1xx` | 硬编码检测 | SC100, SC101, SC102 |
| `SC2xx` | 加密安全检测 | SC200, SC201, SC202, SC203 |
| `SC3xx` | 网络安全检测 | SC300, SC301 |
| `SC4xx` | 权限安全检测 | SC400, SC401 |

---

**版本**: 1.0  
**生效日期**: 2024年  
**适用范围**: Bandit 敏感信息检测插件项目